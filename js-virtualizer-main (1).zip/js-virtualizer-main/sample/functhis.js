

// @virtualize
function random() {
    return 0.5.toString().slice(2, 5).split('').map(Number)
}

console.log(random())
