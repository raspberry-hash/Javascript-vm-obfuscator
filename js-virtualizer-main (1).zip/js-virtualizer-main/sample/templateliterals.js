
const multiplier = 2;

// @virtualize
function evaluate(a, b) {
    console.log(`Summing ${a} and ${b}`)
}

evaluate(1, 2)
